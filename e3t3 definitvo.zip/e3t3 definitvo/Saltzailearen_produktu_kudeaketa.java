package erronka;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Saltzailearen_produktu_kudeaketa {
	private JFrame produktu_bilatzailea_Frame = new JFrame("Produktuak kudeatu");
	private JLabel produktu_hasiera_mezua_testua = new JLabel("Zer kudeaketak egin nahi duzu?");
	private JButton produktu_gehitu = new JButton("Produktuak gehitu");
	private JButton produktu_kendu = new JButton("Produktu kendu");
	private JButton produktu_aldatu = new JButton("Produktuen informazioa aldatu");
	private JPanel produktuak_bilatu_panela_textua = new JPanel();
	private JPanel produktuak_bilatu_panela_botoiak = new JPanel(new FlowLayout());
	
	
	Saltzailearen_produktu_kudeaketa() {
		
		produktu_gehitu.addActionListener(new ActionListener() {
       	public void actionPerformed(ActionEvent e) {
       		produktu_bilatzailea_Frame.dispose();
       		Saltzaile_produktuak_gehitu b = new Saltzaile_produktuak_gehitu();
            }
       });
		
		produktu_kendu.addActionListener(new ActionListener() {
       	public void actionPerformed(ActionEvent e) {
       		produktu_bilatzailea_Frame.dispose();
       		Saltzaile_produktuak_kendu a = new Saltzaile_produktuak_kendu();
            }
       });
		
		produktu_aldatu.addActionListener(new ActionListener() {
       	public void actionPerformed(ActionEvent e) {
       		produktu_bilatzailea_Frame.dispose();
       		Saltzaile_produktuak_aldatu c = new Saltzaile_produktuak_aldatu();
            }
       });
		
		produktuak_bilatu_panela_textua.add(produktu_hasiera_mezua_testua);
		produktuak_bilatu_panela_botoiak.add(produktu_gehitu);
		produktuak_bilatu_panela_botoiak.add(produktu_kendu);
		produktuak_bilatu_panela_botoiak.add(produktu_aldatu);
		produktu_bilatzailea_Frame.add(produktuak_bilatu_panela_textua, BorderLayout.NORTH);
		produktu_bilatzailea_Frame.add(produktuak_bilatu_panela_botoiak);
		produktu_bilatzailea_Frame.setSize(new Dimension(350, 140));
		produktu_bilatzailea_Frame.setLocationRelativeTo(null);
		produktu_bilatzailea_Frame.setVisible(true);
	}
}