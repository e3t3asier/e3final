package erronka;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.ArrayList;

public class Bezero_produktuak_bilatu {
	private static String a;

	private JFrame bezero_produktuak_bilatu_Frame = new JFrame("Produktuak bilatu");
	private JLabel bezero_produktuak_bilatu_Label = new JLabel("Izena:");
	private JTextField produktuaren_izena = new JTextField("Corsair Dominator Platinum");
	private JSlider bezero_produktuak_bilatu_PMinimoa = new JSlider(0, 10000);
	private JSlider bezero_produktuak_bilatu_PMaximoa = new JSlider(0, 10000);
	private JLabel balioaMaxLabel = new JLabel("Gutxieneko prezioa: x");
	private JLabel balioaMinLabel = new JLabel("Genienezko prezioa: x");
	private JButton produktuak_bilatzeko_botoia = new JButton("Produktuak bilatu");
	private JButton lista_erakusteko_botoia = new JButton("Eskaerak ikusi");

	private JFrame resultsFrame = null;
	private ArrayList<Object[]> hautatutako_gauzak = new ArrayList<>();
	private JPanel bezero_produktuak_bilatu_Panel = new JPanel(new GridLayout(3, 2));
	private JPanel bezero_produktuak_bilatu_Panel_textua = new JPanel();

	Bezero_produktuak_bilatu() {
		bezero_produktuak_bilatu_Panel.add(bezero_produktuak_bilatu_Label);
		bezero_produktuak_bilatu_Panel.add(produktuaren_izena);
		bezero_produktuak_bilatu_Panel.add(balioaMinLabel);
		bezero_produktuak_bilatu_Panel.add(bezero_produktuak_bilatu_PMinimoa);
		bezero_produktuak_bilatu_Panel.add(balioaMaxLabel);
		bezero_produktuak_bilatu_Panel.add(bezero_produktuak_bilatu_PMaximoa);
		bezero_produktuak_bilatu_Panel_textua.add(bezero_produktuak_bilatu_Panel);
		bezero_produktuak_bilatu_Frame.add(bezero_produktuak_bilatu_Panel_textua, BorderLayout.NORTH);

		JPanel botoi_panela = new JPanel();
		botoi_panela.add(produktuak_bilatzeko_botoia);
		botoi_panela.add(lista_erakusteko_botoia);
		bezero_produktuak_bilatu_Frame.add(botoi_panela, BorderLayout.SOUTH);

		bezero_produktuak_bilatu_PMinimoa.addChangeListener(
				e -> balioaMinLabel.setText("Gutxieneko prezioa: " + bezero_produktuak_bilatu_PMinimoa.getValue()));
		bezero_produktuak_bilatu_PMaximoa.addChangeListener(
				e -> balioaMaxLabel.setText("Genienezko prezioa: " + bezero_produktuak_bilatu_PMaximoa.getValue()));

		produktuak_bilatzeko_botoia.addActionListener(e -> {
			String url = "jdbc:oracle:thin:@//localhost:1521/xe";
			String user = "oier2";
			String pass = "oier2";

			String kontsulta = "SELECT * FROM PRODUKTU WHERE IZENA LIKE ? AND BALIOA < ? AND BALIOA > ?";

			try (Connection conn = DriverManager.getConnection(url, user, pass);
					PreparedStatement stmt = conn.prepareStatement(kontsulta)) {
				stmt.setString(1, "%" + produktuaren_izena.getText() + "%");
				stmt.setDouble(2, bezero_produktuak_bilatu_PMaximoa.getValue());
				stmt.setDouble(3, bezero_produktuak_bilatu_PMinimoa.getValue());

				ResultSet rs2 = stmt.executeQuery();
				int numRows = 0;
				while (rs2.next()) {
				    numRows++;
				}
				
				ResultSet rs = stmt.executeQuery();
				
				Object[][] kontsulta_osoa = new Object[numRows][6];
				int x = 0;
				while (rs.next()) {
					kontsulta_osoa[x][0] = rs.getInt("ID");
					kontsulta_osoa[x][1] = rs.getString("IZENA");
					kontsulta_osoa[x][2] = rs.getString("DESKRIBAPENA");
					kontsulta_osoa[x][3] = rs.getDouble("BALIOA");
					kontsulta_osoa[x][4] = rs.getDouble("SALNEURRIA");
					kontsulta_osoa[x][5] = rs.getInt("ID_KATEGORIA");
					x++;
				}

				if (resultsFrame != null) {
					resultsFrame.dispose();
				}

				resultsFrame = new JFrame("Bilatzailearen emaitza");
				JPanel resultsPanel = new JPanel(new GridBagLayout());
				GridBagConstraints gbc = new GridBagConstraints();
				gbc.gridx = 0;
				gbc.gridy = 0;
				gbc.anchor = GridBagConstraints.WEST;

				for (int y = 0; y < x; y++) {
					final int lerroa = y;
					JLabel resultLabel = new JLabel("Izena: " + kontsulta_osoa[y][1]
							+ "     Deskribapena: " + kontsulta_osoa[y][2]
							+ "     Salneurria: " + kontsulta_osoa[y][4]);
					resultsPanel.add(resultLabel, gbc);

					JCheckBox checkBox = new JCheckBox("Seleccionar");
					checkBox.addActionListener(evt -> {
						if (checkBox.isSelected()) {
						    hautatutako_gauzak.add(new Object[]{kontsulta_osoa[lerroa][0], kontsulta_osoa[lerroa][1], kontsulta_osoa[lerroa][2], kontsulta_osoa[lerroa][4]});
						} else {
						    hautatutako_gauzak.remove(kontsulta_osoa[lerroa]);
						}

					});
					gbc.gridx = 1;
					resultsPanel.add(checkBox, gbc);

					gbc.gridy++;
					gbc.gridx = 0;
				}

				JScrollPane emaitza_panela_amaitzeko = new JScrollPane(resultsPanel);
				JPanel emaitza_panela_amaitzeko_panel = new JPanel();
				emaitza_panela_amaitzeko_panel.add(emaitza_panela_amaitzeko);
				resultsFrame.add(emaitza_panela_amaitzeko_panel);

				JButton lista_eguneratu = new JButton("Listan gorde");
				lista_eguneratu.addActionListener(evt -> {
					resultsFrame.dispose();
				});
				JPanel lista_eguneratuta = new JPanel();
				lista_eguneratuta.add(lista_eguneratu);
				resultsFrame.add(lista_eguneratuta, BorderLayout.SOUTH);

				resultsFrame.pack();
				resultsFrame.setLocationRelativeTo(null);
				resultsFrame.setVisible(true);
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		});

		lista_erakusteko_botoia.addActionListener(e -> {
			bezeroaren_lista_erakutsi();
			
		});

		bezero_produktuak_bilatu_Frame.pack();
		bezero_produktuak_bilatu_Frame.setLocationRelativeTo(null);
		bezero_produktuak_bilatu_Frame.setVisible(true);
	}

	private void bezeroaren_lista_erakutsi() {
		JFrame lista_konfirmatzeko_Frame = new JFrame("Lista konfirmatu");
		JButton lista_konfirmatzeko_Botoia = new JButton("Kantitateak kudeatu");
		JTextArea listaTextArea = new JTextArea(10, 30);
		listaTextArea.setEditable(false);
		JScrollPane skroleatzeko = new JScrollPane(listaTextArea);
		
		JPanel konfirmatu_botoi_panela = new JPanel();
		konfirmatu_botoi_panela.add(lista_konfirmatzeko_Botoia);
		
		JPanel skroleatzeko_panel = new JPanel();
		skroleatzeko_panel.add(skroleatzeko);
		lista_konfirmatzeko_Frame.add(skroleatzeko_panel, BorderLayout.NORTH);
		lista_konfirmatzeko_Frame.add(konfirmatu_botoi_panela, BorderLayout.SOUTH);

		for (Object[] gauza : hautatutako_gauzak) {
			for (Object o : gauza) {
				listaTextArea.append(o + "     ");
			}
			listaTextArea.append("\n");
		}

		lista_konfirmatzeko_Botoia.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				lista_konfirmatzeko_Frame.dispose();
				a = listaTextArea.getText();

				bezero_produktuak_bilatu_Frame.dispose();
				Bezero_hautatutako_produktuak ooio = new Bezero_hautatutako_produktuak();
			}
		});

		lista_konfirmatzeko_Frame.pack();
		lista_konfirmatzeko_Frame.setLocationRelativeTo(null);
		lista_konfirmatzeko_Frame.setVisible(true);
	}

	public static String getA() {
		return a;
	}
}
