package erronka;


import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class Saltzaile_saiora_sartu {

    String url = "jdbc:oracle:thin:@localhost:1521:xe";
    String user = "oier2";
    String pass = "oier2";

    private JFrame saioa_hasi_Frame = new JFrame("Saltzaile saioa hasi");
    private JLabel erabiltzaileaL = new JLabel("Erabiltzailea:");
    private JLabel pasahitzaL = new JLabel("Pasahitza:");
    private JTextField erabiltzaileaT = new JTextField(10);
    private JPasswordField pasahitzaT = new JPasswordField(10);
    private JButton saioa_hasi_botoia = new JButton("Saioa hasi");
    private JPanel saioa_hasi_panela = new JPanel(new GridLayout(2, 2));
    private JPanel saltzaile_saioa_hasi_panela = new JPanel();
    

    Saltzaile_saiora_sartu() {
        saioa_hasi_botoia.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try (Connection konexioa = DriverManager.getConnection(url, user, pass)) {
                    String erabiltzailea = erabiltzaileaT.getText();
                    String pasahitza = new String(pasahitzaT.getPassword());
                    String kontsulta = "SELECT COUNT(*) AS count FROM SALTZAILE WHERE ERABILTZAILEA = ? AND PASAHITZA = ?";
                    try (PreparedStatement st = konexioa.prepareStatement(kontsulta)) {
                        st.setString(1, erabiltzailea);
                        st.setString(2, pasahitza);
                        ResultSet rs = st.executeQuery();
                        if (rs.next()) {
                            int count = rs.getInt("count");
                            if (count > 0) {
                                Saltzaile_hasiera_menua a = new Saltzaile_hasiera_menua();
                                saioa_hasi_Frame.dispose();
                            } else {
                                Saio_hasieraren_errore_mezua aaa = new Saio_hasieraren_errore_mezua();
                            }
                        }
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        });
        saioa_hasi_panela.add(erabiltzaileaL);
        saioa_hasi_panela.add(erabiltzaileaT);
        saioa_hasi_panela.add(pasahitzaL);
        saioa_hasi_panela.add(pasahitzaT);

        saltzaile_saioa_hasi_panela.add(saioa_hasi_panela);
        
        saioa_hasi_Frame.add(saltzaile_saioa_hasi_panela, BorderLayout.CENTER);
        
        JPanel b = new JPanel();
        b.add(saioa_hasi_botoia);
        saioa_hasi_Frame.add(b, BorderLayout.SOUTH);

        saioa_hasi_Frame.setVisible(true);
        saioa_hasi_Frame.setSize(new Dimension(300, 130));
        saioa_hasi_Frame.setLocationRelativeTo(null);

    }
}
