package erronka;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Saio_hasieraren_errore_mezua {

	Saio_hasieraren_errore_mezua() {
		JFrame errorea = new JFrame("Errorea");
		JButton errorea_botoia = new JButton("Saiatu berriro");
		JLabel errorea_label = new JLabel("Erabiltzailea edo pasahitza ez dira zuzenak.");
		JPanel errorea_texto_panel = new JPanel();

		errorea_botoia.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				errorea.dispose();
			}
		});
		errorea_texto_panel.add(errorea_label, BorderLayout.NORTH);
		errorea.add(errorea_texto_panel, BorderLayout.CENTER);
		errorea.add(errorea_botoia, BorderLayout.SOUTH);
		errorea.setSize(new Dimension(300, 100));
		errorea.setLocationRelativeTo(null);
		errorea.setVisible(true);
	}
}
