package erronka;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Erabiltzaile_sortu {
	private static String url = "jdbc:oracle:thin:@//localhost:1521/xe";
	private static String user = "oier2";
	private static String pass = "oier2";
	private static String maxId = "";

	private JFrame erabiltzaile_sortu = new JFrame("Bezeroa sortu");
	private JLabel erabiltzaile_sortu_label = new JLabel("Bezero erabiltzaile bat sortu nahi duzu?");
	private JButton sortu_bezero_bai = new JButton("Bai");
	private JButton sortu_bezero_ez = new JButton("Ez");
	private JPanel sortu_botoiak = new JPanel();
	private JPanel sortu_panel = new JPanel();

	Erabiltzaile_sortu() {

		sortu_bezero_bai.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Bezero_sortu a = new Bezero_sortu();
				erabiltzaile_sortu.dispose();
			}
		});

		sortu_bezero_ez.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Saioa_hasi_edo_kontua_sortu a = new Saioa_hasi_edo_kontua_sortu();
				erabiltzaile_sortu.dispose();
			}
		});

		sortu_botoiak.add(sortu_bezero_bai, BorderLayout.EAST);
		sortu_botoiak.add(sortu_bezero_ez, BorderLayout.WEST);
		sortu_panel.add(erabiltzaile_sortu_label, BorderLayout.NORTH);
		
		erabiltzaile_sortu.add(sortu_panel, BorderLayout.CENTER);
		erabiltzaile_sortu.add(sortu_botoiak, BorderLayout.SOUTH);
		erabiltzaile_sortu.pack();
		erabiltzaile_sortu.setPreferredSize(new Dimension(300, 100));
		erabiltzaile_sortu.setLocationRelativeTo(null);
		erabiltzaile_sortu.setVisible(true);
	}

	public void setMaxId(String maxId) {
		this.maxId = maxId;
	}

	public static String getMaxId() {
		Saioa_hasi_edo_kontua_sortu a = new Saioa_hasi_edo_kontua_sortu();
		try (Connection konexioa = DriverManager.getConnection(url, user, pass)) {
			String kontsulta = "select max(id) as max_id from bezero";
			try (PreparedStatement st = konexioa.prepareStatement(kontsulta)) {
				ResultSet rs = st.executeQuery();
				if (rs.next()) {
					maxId = rs.getString("max_id");
					int maxID = Integer.parseInt(maxId);
					maxID++;
					maxId = Integer.toString(maxID);
				}
			}
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		return maxId;
	}
}
