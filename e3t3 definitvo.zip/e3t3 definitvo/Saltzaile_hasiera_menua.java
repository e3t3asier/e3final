package erronka;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Saltzaile_hasiera_menua {
	private JFrame erabiltzaileAdmin_menu_Frame = new JFrame("Saltzaile menu");
	private JPanel erabiltzaileAdmin_menu_Panela = new JPanel();
	private JPanel erabiltzaileAdmin_menu_Panela_textua = new JPanel();
	private JButton saioa_itxi = new JButton("Saioa itxi");
	private JButton info_aldatu = new JButton("Produktuak kudeatu");
	private JLabel testua = new JLabel("Zer egin nahi duzu?");

	Saltzaile_hasiera_menua() {
		saioa_itxi.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				erabiltzaileAdmin_menu_Frame.dispose();
				Saioa_hasi_edo_kontua_sortu aaaa = new Saioa_hasi_edo_kontua_sortu();
			}
		});

		info_aldatu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				erabiltzaileAdmin_menu_Frame.dispose();
				Saltzailearen_produktu_kudeaketa a = new Saltzailearen_produktu_kudeaketa();
			}
		});
		erabiltzaileAdmin_menu_Frame.setSize(new Dimension(400, 110));
		erabiltzaileAdmin_menu_Panela_textua.add(testua, BorderLayout.CENTER);
		erabiltzaileAdmin_menu_Frame.add(erabiltzaileAdmin_menu_Panela_textua, BorderLayout.CENTER);
		erabiltzaileAdmin_menu_Panela.add(info_aldatu, BorderLayout.SOUTH);
		erabiltzaileAdmin_menu_Panela.add(saioa_itxi, BorderLayout.NORTH);
		erabiltzaileAdmin_menu_Frame.add(erabiltzaileAdmin_menu_Panela, BorderLayout.SOUTH);
		erabiltzaileAdmin_menu_Frame.setLocationRelativeTo(null);
		erabiltzaileAdmin_menu_Frame.setVisible(true);
	}
}
