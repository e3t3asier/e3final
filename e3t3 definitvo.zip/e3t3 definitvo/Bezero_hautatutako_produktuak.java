package erronka;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.*;

public class Bezero_hautatutako_produktuak {
	private static int produktuID;
	private static int[] abc;
	private JFrame bezero_hautatutako_produktuak_Frame = new JFrame("Kantitateak kudeatu");
	private JPanel bezero_hautatutako_produktuak_Panel = new JPanel();
	private JPanel bezero_hautatutako_produktuak_botoi_panel = new JPanel();
	private JPanel bezero_hautatutako_produktuak_datuak_panel = new JPanel();

	private JButton gordetzeko_botoia = new JButton("Gorde");
	private JTextField[] zenbakiak_jartzeko;
	private JLabel[] unitateak_maximoak_Label;
	private String url = "jdbc:oracle:thin:@//localhost:1521/xe";
	private String user = "oier2";
	private String pass = "oier2";

	public Bezero_hautatutako_produktuak() {
		String eskaera_lista = Bezero_produktuak_bilatu.getA();
		String[] lerroak = eskaera_lista.split("\n");
		bezero_hautatutako_produktuak_Panel.setLayout(new GridLayout(0, 1));
		zenbakiak_jartzeko = new JTextField[lerroak.length];
		unitateak_maximoak_Label = new JLabel[lerroak.length];
		String[] kodeak = new String[lerroak.length];
		try (Connection connection = DriverManager.getConnection(url, user, pass)) {
			for (int x = 0; x < lerroak.length; x++) {
				JPanel informazioa = new JPanel();
				String[] datua = lerroak[x].split(" ");
				StringBuilder lineText = new StringBuilder();
				for (String datu : datua) {
					lineText.append(datu).append(" ||| ");
				}
				JLabel label = new JLabel(lineText.toString());
				JTextField textField = new JTextField(10);
				JLabel banakako_unitate_maximoa_Label = new JLabel();
				informazioa.add(label);
				informazioa.add(textField);
				informazioa.add(banakako_unitate_maximoa_Label);
				bezero_hautatutako_produktuak_Panel.add(informazioa);
				zenbakiak_jartzeko[x] = textField;
				unitateak_maximoak_Label[x] = banakako_unitate_maximoa_Label;
				kodeak[x] = datua[0];
				produktuID = Integer.parseInt(datua[0]);
				int maximoa2 = getMaxQuantity(connection, produktuID);
				banakako_unitate_maximoa_Label.setText("Max: " + maximoa2);
				abc = new int[lerroak.length];
				abc[x] = 0;

			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		bezero_hautatutako_produktuak_Panel.add(gordetzeko_botoia);
		gordetzeko_botoia.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				for (int i = 0; i < zenbakiak_jartzeko.length; i++) {
					int maximoen_parseaketa = Integer.parseInt(unitateak_maximoak_Label[i].getText().split(" ")[1]);
					int enteredQuantity = Integer.parseInt(zenbakiak_jartzeko[i].getText());
					abc[i] = Integer.parseInt(zenbakiak_jartzeko[i].getText());// NUEVO
					if (enteredQuantity > maximoen_parseaketa || enteredQuantity <= -1) {
						JOptionPane.showMessageDialog(bezero_hautatutako_produktuak_Frame,
								"Ezinezkoa da gehiago erosi, mesedez sartu balio egokiak.", "Errorea.",
								JOptionPane.ERROR_MESSAGE);
						return;
					}
				}
				int[][] datos = new int[zenbakiak_jartzeko.length][2];
				for (int i = 0; i < zenbakiak_jartzeko.length; i++) {
					int id = Integer.parseInt(lerroak[i].split(" ")[0]);
					datos[i][0] = id;
					datos[i][1] = abc[i];
				}
				actualizarTablasEskari(1, datos);

				int[] eskatutako_kopurua = new int[zenbakiak_jartzeko.length];
				for (int x = 0; x < zenbakiak_jartzeko.length; x++) {
					try {
						eskatutako_kopurua[x] = Integer.parseInt(zenbakiak_jartzeko[x].getText());
						System.out.println("Cantidad obtenida del usuario: " + eskatutako_kopurua[x]);
					} catch (NumberFormatException ex) {
						eskatutako_kopurua[x] = 0;
					}
				}
				int maximoa = Math.max(kodeak.length, eskatutako_kopurua.length);
				int[][] id_eta_kantitateak = new int[maximoa][2];
				for (int x = 0; x < maximoa; x++) {
					if (x < kodeak.length) {
						id_eta_kantitateak[x][0] = Integer.parseInt(kodeak[x]);
					}
					if (x < eskatutako_kopurua.length) {
						id_eta_kantitateak[x][1] = eskatutako_kopurua[x];
					}
				}
				try (Connection connection = DriverManager.getConnection(url, user, pass)) {
					for (int[] id_eta_kantitatea : id_eta_kantitateak) {
						int idProduktu = id_eta_kantitatea[0];
						int kantitatea = id_eta_kantitatea[1];
						int unitateak = 0;
						String kontsulta = "SELECT SUM(KOPURUA) FROM INBENTARIO WHERE ID_PRODUKTU = ?";
						try (PreparedStatement totalStatement = connection.prepareStatement(kontsulta)) {
							totalStatement.setInt(1, idProduktu);
							try (ResultSet rsTotal = totalStatement.executeQuery()) {
								if (rsTotal.next()) {
									unitateak = rsTotal.getInt(1);
								}
							}
						}
						if (kantitatea <= unitateak) {
							boolean a = false;
							for (int idBiltegi = 1; idBiltegi <= 10; idBiltegi++) {
								int kantitate_eskuragarria = 0;
								String kopurua_lortu = "SELECT KOPURUA FROM INBENTARIO WHERE ID_PRODUKTU = ? AND ID_BILTEGI = ?";
								try (PreparedStatement kopurua = connection.prepareStatement(kopurua_lortu)) {
									kopurua.setInt(1, idProduktu);
									kopurua.setInt(2, idBiltegi);
									try (ResultSet kantitatea_emaitza = kopurua.executeQuery()) {
										if (kantitatea_emaitza.next()) {
											kantitate_eskuragarria = kantitatea_emaitza.getInt(1);
										}
									}
								}
								if (kantitate_eskuragarria > 0) {
									if (kantitate_eskuragarria >= kantitatea) {
										String kantitateak_eguneratu = "UPDATE INBENTARIO SET KOPURUA = KOPURUA - ? WHERE ID_PRODUKTU = ? AND ID_BILTEGI = ?";
										try (PreparedStatement kantitateak_eguneratu_st = connection
												.prepareStatement(kantitateak_eguneratu)) {
											kantitateak_eguneratu_st.setInt(1, kantitatea);
											kantitateak_eguneratu_st.setInt(2, idProduktu);
											kantitateak_eguneratu_st.setInt(3, idBiltegi);
											kantitateak_eguneratu_st.executeUpdate();
										}
										a = true;
										Informazio_mezuak.mezu_ona(
												"Produktu guztiak ondo egin dira! Biltegia: (" + idBiltegi + ").");
										break;
									} else {
										kantitatea -= kantitate_eskuragarria;
										String kantitateak_eguneratu2 = "UPDATE INBENTARIO SET KOPURUA = 0 WHERE ID_PRODUKTU = ? AND ID_BILTEGI = ?";
										try (PreparedStatement kantitateak_eguneratu_st2 = connection
												.prepareStatement(kantitateak_eguneratu2)) {
											kantitateak_eguneratu_st2.setInt(1, idProduktu);
											kantitateak_eguneratu_st2.setInt(2, idBiltegi);
											kantitateak_eguneratu_st2.executeUpdate();
										}
									}
								}
							}
						}
					}
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				bezero_hautatutako_produktuak_Frame.dispose();
			}
		});
		bezero_hautatutako_produktuak_datuak_panel.add(bezero_hautatutako_produktuak_Panel);
		bezero_hautatutako_produktuak_Frame.add(bezero_hautatutako_produktuak_datuak_panel);
		bezero_hautatutako_produktuak_botoi_panel.add(gordetzeko_botoia);
		bezero_hautatutako_produktuak_Frame.add(bezero_hautatutako_produktuak_botoi_panel, BorderLayout.SOUTH);
		bezero_hautatutako_produktuak_Frame.add(bezero_hautatutako_produktuak_Panel);
		bezero_hautatutako_produktuak_Frame.pack();
		bezero_hautatutako_produktuak_Frame.setPreferredSize(new Dimension(500, 500));
		bezero_hautatutako_produktuak_Frame.setLocationRelativeTo(null);
		bezero_hautatutako_produktuak_Frame.setVisible(true);
	}

	private int getMaxQuantity(Connection connection, int idProducto) {
		int maxQuantity = 0;
		String sqlCantidadTotal = "SELECT SUM(KOPURUA) FROM INBENTARIO WHERE ID_PRODUKTU = ?";
		try (PreparedStatement totalStatement = connection.prepareStatement(sqlCantidadTotal)) {
			totalStatement.setInt(1, idProducto);
			try (ResultSet rsTotal = totalStatement.executeQuery()) {
				if (rsTotal.next()) {
					maxQuantity = rsTotal.getInt(1);
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return maxQuantity;
	}

	private void actualizarTablasEskari(int idBezero, int[][] idEtaKantitateak) {
		for (int a = 0; a < idEtaKantitateak.length; a++) {
			try (Connection connection = DriverManager.getConnection(url, user, pass)) {
				connection.setAutoCommit(false);

				int idEskari = obtenerNuevoIdEskari(connection);

				String sqlInsertEskari = "INSERT INTO ESKARI (ID, ID_BEZERO, ID_EGOERA, ID_SALTZAILE, ESKAERA_DATA) VALUES (?, ?, ?, ?, ?)";
				try (PreparedStatement stmtInsertEskari = connection.prepareStatement(sqlInsertEskari)) {
					stmtInsertEskari.setInt(1, idEskari);
					stmtInsertEskari.setInt(2, idBezero);
					stmtInsertEskari.setInt(3, 1);
					stmtInsertEskari.setInt(4, 51);
					stmtInsertEskari.setDate(5, new Date(System.currentTimeMillis()));
					stmtInsertEskari.executeUpdate();
				}

				String sqlInsertEskariLerro = "INSERT INTO ESKARI_LERRO (ID_ESKARI, ID_LERRO, ID_PRODUKTU, KOPURUA, SALNEURRIA) VALUES (?, ?, ?, ?, ?)";
				try (PreparedStatement stmtInsertEskariLerro = connection.prepareStatement(sqlInsertEskariLerro)) {
					int idLerro = a + 1;

					stmtInsertEskariLerro.setInt(1, idEskari);
					stmtInsertEskariLerro.setInt(2, idLerro);
					stmtInsertEskariLerro.setInt(3, idEtaKantitateak[a][0]);
					stmtInsertEskariLerro.setInt(4, idEtaKantitateak[a][1]);
					stmtInsertEskariLerro.setDouble(5, 45);
					stmtInsertEskariLerro.executeUpdate();

					System.out.println("Insert realizado correctamente para la fila " + idLerro);
				}

				connection.commit();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	private int obtenerNuevoIdEskari(Connection connection) throws SQLException {
		int nuevoId = 1;
		String sqlObtenerMaxId = "SELECT MAX(ID) FROM ESKARI";
		try (PreparedStatement stmtMaxId = connection.prepareStatement(sqlObtenerMaxId);
				ResultSet rsMaxId = stmtMaxId.executeQuery()) {
			if (rsMaxId.next()) {
				nuevoId = rsMaxId.getInt(1) + 1;
			}
		}
		return nuevoId;
	}
}