package erronka;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class Bezero_datuak_aldatu {
	private String url = "jdbc:oracle:thin:@//localhost:1521/xe";
	private String user = "oier2";
	private String pass = "oier2";
	private String[] bezeroaren_informazioa = new String[4];

	private JFrame bezero_datuak_aldatu_Frame = new JFrame("Datuak aldatu");

	private JLabel bezero_datuak_aldatu_label_id = new JLabel("ID: ");
	private JLabel bezero_datuak_aldatu_label_izena = new JLabel("Izena: ");
	private JLabel bezero_datuak_aldatu_label_abizena = new JLabel("Abizena: ");
	private JLabel bezero_datuak_aldatu_label_helbidea = new JLabel("Helbidea: ");
	private JLabel bezero_datuak_aldatu_label_emaila = new JLabel("Emaila (pasahitza): ");

	private JLabel bezero_datuak_aldatu_label_idT = new JLabel(Integer.toString(Bezero_saiora_sartu.getClientId()));
	private JTextField bezero_datuak_aldatu_label_izenaT = new JTextField();
	private JTextField bezero_datuak_aldatu_label_abizenaT = new JTextField();
	private JTextField bezero_datuak_aldatu_label_helbideaT = new JTextField();
	private JTextField bezero_datuak_aldatu_label_emailaT = new JTextField();

	private JButton bezero_datuak_aldatu_Button = new JButton("Datuak aldatu");
	private JPanel bezero_datuak_aldatu_Panel = new JPanel(new GridLayout(5, 2));
	private JPanel bezero_datuak_aldatu_Panel_text = new JPanel();
	private JPanel bezero_datuak_aldatu_Panel_button = new JPanel();


	Bezero_datuak_aldatu() {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;

		try {
			conn = DriverManager.getConnection(url, user, pass);
			int id = Bezero_saiora_sartu.getClientId();
			String kontsulta = "SELECT * FROM BEZERO WHERE ID = ?";
			stmt = conn.prepareStatement(kontsulta);
			stmt.setInt(1, id);
			rs = stmt.executeQuery();
			if (rs.next()) {
				
				bezeroaren_informazioa[0] = rs.getString("IZENA");
				bezeroaren_informazioa[1] = rs.getString("ABIZENA");
				bezeroaren_informazioa[2] = rs.getString("HELBIDEA");
				bezeroaren_informazioa[3] = rs.getString("EMAILA");

				bezero_datuak_aldatu_label_izenaT.setText(bezeroaren_informazioa[0]);
				bezero_datuak_aldatu_label_abizenaT.setText(bezeroaren_informazioa[1]);
				bezero_datuak_aldatu_label_helbideaT.setText(bezeroaren_informazioa[2]);
				bezero_datuak_aldatu_label_emailaT.setText(bezeroaren_informazioa[3]);
			} else {
				Informazio_mezuak.mezu_errorea("Zeozer txarti gertatu da. Saiatu berriz, mesedez.");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (stmt != null)
					stmt.close();
				if (conn != null)
					conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		bezero_datuak_aldatu_Button.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		        bezeroaren_informazioa[0] = bezero_datuak_aldatu_label_izenaT.getText();
		        bezeroaren_informazioa[1] = bezero_datuak_aldatu_label_abizenaT.getText();
		        bezeroaren_informazioa[2] = bezero_datuak_aldatu_label_helbideaT.getText();
		        bezeroaren_informazioa[3] = bezero_datuak_aldatu_label_emailaT.getText();
		        
		        try {
		            Connection conn = DriverManager.getConnection(url, user, pass);
		            String sql = "UPDATE BEZERO SET IZENA = ?, ABIZENA = ?, HELBIDEA = ?, EMAILA = ? WHERE ID = ?";
		            PreparedStatement pstmt = conn.prepareStatement(sql);
		            int id = Bezero_saiora_sartu.getClientId();
		            
		            pstmt.setString(1, bezeroaren_informazioa[0]);
		            pstmt.setString(2, bezeroaren_informazioa[1]);
		            pstmt.setString(3, bezeroaren_informazioa[2]);
		            pstmt.setString(4, bezeroaren_informazioa[3]);
		            pstmt.setInt(5, id);
		            
		            int rowsAffected = pstmt.executeUpdate();
		            
		            if (rowsAffected > 0) {
		            	Informazio_mezuak.mezu_ona("Ondo atera da!");
		           		Bezero_hasiera_menua aaa = new Bezero_hasiera_menua();
		           		
		            } else {
		            	Informazio_mezuak.mezu_errorea("Zeozer txarto gertatu da. Saiatu berriz, mesedez.");
		           		Bezero_datuak_aldatu a = new Bezero_datuak_aldatu();
		            }
		            pstmt.close();
		            conn.close();
		            
		        } catch (SQLException ex) {
		            ex.printStackTrace();
		        }
		        
		        bezero_datuak_aldatu_Frame.dispose();
		        
		    }
		});

		bezero_datuak_aldatu_Panel.add(bezero_datuak_aldatu_label_id);
		bezero_datuak_aldatu_Panel.add(bezero_datuak_aldatu_label_idT);
		bezero_datuak_aldatu_Panel.add(bezero_datuak_aldatu_label_izena);
		bezero_datuak_aldatu_Panel.add(bezero_datuak_aldatu_label_izenaT);
		bezero_datuak_aldatu_Panel.add(bezero_datuak_aldatu_label_abizena);
		bezero_datuak_aldatu_Panel.add(bezero_datuak_aldatu_label_abizenaT);
		bezero_datuak_aldatu_Panel.add(bezero_datuak_aldatu_label_helbidea);
		bezero_datuak_aldatu_Panel.add(bezero_datuak_aldatu_label_helbideaT);
		bezero_datuak_aldatu_Panel.add(bezero_datuak_aldatu_label_emaila);
		bezero_datuak_aldatu_Panel.add(bezero_datuak_aldatu_label_emailaT);

		bezero_datuak_aldatu_Panel_text.add(bezero_datuak_aldatu_Panel);
		bezero_datuak_aldatu_Panel_button.add(bezero_datuak_aldatu_Button);
		
		bezero_datuak_aldatu_Frame.add(bezero_datuak_aldatu_Panel_text, BorderLayout.CENTER);
		bezero_datuak_aldatu_Frame.add(bezero_datuak_aldatu_Panel_button, BorderLayout.SOUTH);
				
		bezero_datuak_aldatu_Frame.add(bezero_datuak_aldatu_Panel_text);
		bezero_datuak_aldatu_Frame.pack();
		bezero_datuak_aldatu_Frame.setPreferredSize(new Dimension(300, 200));
		bezero_datuak_aldatu_Frame.setLocationRelativeTo(null);
		bezero_datuak_aldatu_Frame.setVisible(true);
	}
}