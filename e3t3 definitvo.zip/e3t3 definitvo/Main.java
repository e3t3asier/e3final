package erronka;

public class Main {
	public static void main(String[] args) {
		String url = "jdbc:oracle:thin:@//localhost:1521/xe";
		String user = "oier2";
		String pass = "oier2";
		Saioa_hasi_edo_kontua_sortu a = new Saioa_hasi_edo_kontua_sortu();
	}
}