package erronka;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class Saltzaile_produktuak_gehitu {
	private JFrame frame = new JFrame();
	private JTextField idField = new JTextField();
	private JTextField izenaField = new JTextField();
	private JTextField deskribapenaField = new JTextField();
	private JTextField balioaField = new JTextField();
	private JTextField salneurriaField = new JTextField();
	private JTextField idKategoriaField = new JTextField();
	private JPanel saltzaile_produktuak_aldatu_Panel = new JPanel(new GridLayout(6, 2));
	private JPanel saltzaile_produktuak_aldatu_textua = new JPanel();
	private JPanel saltzaile_produktuak_aldatu_botoia = new JPanel();

	private JButton addButton = new JButton("Gehitu");

	public Saltzaile_produktuak_gehitu() {
		frame.setTitle("Produktua gehitu");

		saltzaile_produktuak_aldatu_Panel.add(new JLabel("ID"));
		String maxIdQuery = "SELECT MAX(id) FROM produktu";
		try (Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "oier2", "oier2");
				Statement statement = connection.createStatement();
				ResultSet resultSet = statement.executeQuery(maxIdQuery)) {

			if (resultSet.next()) {
				int maxId = resultSet.getInt(1);
				idField.setText(String.valueOf(maxId + 1));
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
			idField.setText("");
		}

		saltzaile_produktuak_aldatu_Panel.add(idField);
		saltzaile_produktuak_aldatu_Panel.add(new JLabel("Izena: "));
		saltzaile_produktuak_aldatu_Panel.add(izenaField);
		saltzaile_produktuak_aldatu_Panel.add(new JLabel("Deskribapena: "));
		saltzaile_produktuak_aldatu_Panel.add(deskribapenaField);
		saltzaile_produktuak_aldatu_Panel.add(new JLabel("Balioa: "));
		saltzaile_produktuak_aldatu_Panel.add(balioaField);
		saltzaile_produktuak_aldatu_Panel.add(new JLabel("Salneurria: "));
		saltzaile_produktuak_aldatu_Panel.add(salneurriaField);
		saltzaile_produktuak_aldatu_Panel.add(new JLabel("ID Kategoria (1-5): "));
		saltzaile_produktuak_aldatu_Panel.add(idKategoriaField);
		saltzaile_produktuak_aldatu_botoia.add(addButton);
		
		saltzaile_produktuak_aldatu_textua.add(saltzaile_produktuak_aldatu_Panel);
		frame.add(saltzaile_produktuak_aldatu_textua, BorderLayout.CENTER);
		frame.add(saltzaile_produktuak_aldatu_botoia,BorderLayout.SOUTH);

		addButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					int idKategoria = Integer.parseInt(idKategoriaField.getText());
					if (idKategoria < 1 || idKategoria > 5) {
						JOptionPane.showMessageDialog(frame, "Errorea: ID kategoria ez da onartua. (1-5) izan behar da");
						return;
					}

					String id = idField.getText();
					String izena = izenaField.getText();
					String deskribapena = deskribapenaField.getText();
					double balioa = Double.parseDouble(balioaField.getText());
					double salneurria = Double.parseDouble(salneurriaField.getText());

					insertProduct(id, izena, deskribapena, balioa, salneurria, idKategoria);
					JOptionPane.showMessageDialog(frame, "Produktua ondo sartu da.");
				} catch (NumberFormatException ex) {
					JOptionPane.showMessageDialog(frame, "Errorea: Balio numerikoa sartu behar da.");
				} catch (SQLException ex) {
					JOptionPane.showMessageDialog(frame, "Errorea: " + ex.getMessage());
				}
			}
		});

		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(new Dimension(300, 200));
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
	}

	private void insertProduct(String id, String izena, String deskribapena, double balioa, double salneurria,
			int idKategoria) throws SQLException {
		String url = "jdbc:oracle:thin:@localhost:1521:xe";
		String user = "oier2";
		String pass = "oier2";
		String insertQuery = "INSERT INTO produktu (id, izena, deskribapena, balioa, salneurria, id_kategoria) VALUES (?, ?, ?, ?, ?, ?)";

		try (Connection connection = DriverManager.getConnection(url, user, pass);
				PreparedStatement preparedStatement = connection.prepareStatement(insertQuery)) {

			preparedStatement.setString(1, id);
			preparedStatement.setString(2, izena);
			preparedStatement.setString(3, deskribapena);
			preparedStatement.setDouble(4, balioa);
			preparedStatement.setDouble(5, salneurria);
			preparedStatement.setInt(6, idKategoria);

			preparedStatement.executeUpdate();
		}
	}
}
