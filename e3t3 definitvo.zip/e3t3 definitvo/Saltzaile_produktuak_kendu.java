package erronka;


import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class Saltzaile_produktuak_kendu {
    private JFrame saltzaile_produktuak_kendu = new JFrame("Produktuak kendu");
    private JLabel saltzaile_produktuak_kendu_id = new JLabel("Sartu produktuaren ID-a ezabatzeko");
    private JTextField saltzaile_produktuak_kendu_idT = new JTextField(5);
    private JButton saltzaile_produktuak_kendu_Button = new JButton("Ezabatu");
    private JPanel saltzaile_produktuak_boton_panel = new JPanel();

    Saltzaile_produktuak_kendu() {
        saltzaile_produktuak_kendu_Button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String id = saltzaile_produktuak_kendu_idT.getText();

                String[] productInfo = getProductInfo(id);

                if (productInfo != null) {
                    int confirmation = JOptionPane.showConfirmDialog(saltzaile_produktuak_kendu,
                            "Produktua hau ezabatu nahi duzu?\n\nID: " + productInfo[0] +
                            "\nProduktuaren izena: " + productInfo[1] +
                            "\nDeskribapena: " + productInfo[2] +
                            "\nBalioa: " + productInfo[3] + "€" +
                            "\nSalneurria: " + productInfo[4] + "€" +
                            "\nID kategoria: " + productInfo[5],
                            "Produktua Ezabatu", JOptionPane.YES_NO_OPTION);

                    if (confirmation == JOptionPane.YES_OPTION) {
                        if (deleteProduct(id)) {
                            JOptionPane.showMessageDialog(saltzaile_produktuak_kendu, "Produktua (" + id + ") ondo ezabatu da.");
                        } else {
                            JOptionPane.showMessageDialog(saltzaile_produktuak_kendu, "Errorea: Produktua ezin da aurkitu.");
                        }
                        saltzaile_produktuak_kendu.dispose();
                    }
                } else {
                    JOptionPane.showMessageDialog(saltzaile_produktuak_kendu, "Errorea: Produktua ezin da aurkitu.");
                }
            }
        });

        JPanel saltzaile_produktuak_kendu_IDak = new JPanel();
        saltzaile_produktuak_kendu_IDak.add(saltzaile_produktuak_kendu_id);
        saltzaile_produktuak_kendu_IDak.add(saltzaile_produktuak_kendu_idT);
        
        saltzaile_produktuak_boton_panel.add(saltzaile_produktuak_kendu_Button);
        

        saltzaile_produktuak_kendu.add(saltzaile_produktuak_kendu_IDak, BorderLayout.NORTH);
        saltzaile_produktuak_kendu.add(saltzaile_produktuak_boton_panel, BorderLayout.SOUTH);


        saltzaile_produktuak_kendu.pack();
        saltzaile_produktuak_kendu.setPreferredSize(new Dimension(300, 200));
        saltzaile_produktuak_kendu.setLocationRelativeTo(null);
        saltzaile_produktuak_kendu.setVisible(true);
    }

    private String[] getProductInfo(String id) {
        String url = "jdbc:oracle:thin:@localhost:1521:xe";
        String user = "oier2";
        String pass = "oier2";
        String selectQuery = "SELECT * FROM produktu WHERE id = ?";

        try (Connection connection = DriverManager.getConnection(url, user, pass);
             PreparedStatement selectStatement = connection.prepareStatement(selectQuery)) {

            selectStatement.setString(1, id);
            ResultSet resultSet = selectStatement.executeQuery();

            if (resultSet.next()) {
                String[] productInfo = new String[6];
                productInfo[0] = resultSet.getString("id");
                productInfo[1] = resultSet.getString("izena");
                productInfo[2] = resultSet.getString("deskribapena");
                productInfo[3] = resultSet.getString("balioa");
                productInfo[4] = resultSet.getString("salneurria");
                productInfo[5] = resultSet.getString("id_kategoria");
                return productInfo;
            } else {
                return null;
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(saltzaile_produktuak_kendu, "Errorea konektatzean: " + ex.getMessage());
            return null;
        }
    }

    private boolean deleteProduct(String id) {
        String url = "jdbc:oracle:thin:@localhost:1521:xe";
        String user = "oier2";
        String pass = "oier2";
        String checkInventoryQuery = "SELECT COUNT(*) FROM INBENTARIO WHERE ID_PRODUKTU = ?";
        String checkOrderLineQuery = "SELECT COUNT(*) FROM ESKARI_LERRO WHERE ID_PRODUKTU = ?";
        String deleteProductQuery = "DELETE FROM PRODUKTU WHERE ID = ?";

        try (Connection connection = DriverManager.getConnection(url, user, pass);
             PreparedStatement checkInventoryStatement = connection.prepareStatement(checkInventoryQuery);
             PreparedStatement checkOrderLineStatement = connection.prepareStatement(checkOrderLineQuery);
             PreparedStatement deleteProductStatement = connection.prepareStatement(deleteProductQuery)) {

            checkInventoryStatement.setString(1, id);
            ResultSet inventoryResult = checkInventoryStatement.executeQuery();
            inventoryResult.next();
            int inventoryCount = inventoryResult.getInt(1);

            checkOrderLineStatement.setString(1, id);
            ResultSet orderLineResult = checkOrderLineStatement.executeQuery();
            orderLineResult.next();
            int orderLineCount = orderLineResult.getInt(1);

            if (inventoryCount > 0 || orderLineCount > 0) {
                JOptionPane.showMessageDialog(saltzaile_produktuak_kendu, "Produktu honek eskaera pendienteak ditu.");
                return false;
            } else {
                deleteProductStatement.setString(1, id);
                int rowsAffected = deleteProductStatement.executeUpdate();
                return rowsAffected > 0;
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(saltzaile_produktuak_kendu, "Errorea konektatzerakoan: " + ex.getMessage());
            return false;
        }
    }


}
