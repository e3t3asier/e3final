package erronka;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Informazio_mezuak {
	
	public static void mezu_ona(String a) {
	JFrame mezu_ona_Frame = new JFrame("Operaketa egin da");;
	JPanel mezu_ona_Panel_textua = new JPanel();
	JPanel mezu_ona_Panel_botoi = new JPanel();
	JLabel mezu_ona_Label = new JLabel(a);
	JButton mezu_ona_Button = new JButton("Onartu");
	
	mezu_ona_Panel_textua.add(mezu_ona_Label, BorderLayout.NORTH);
	mezu_ona_Panel_botoi.add(mezu_ona_Button, BorderLayout.SOUTH);
	mezu_ona_Frame.add(mezu_ona_Panel_textua, BorderLayout.NORTH);
	mezu_ona_Frame.add(mezu_ona_Panel_botoi);
	
	mezu_ona_Frame.setSize(new Dimension(300, 100));
	mezu_ona_Frame.setLocationRelativeTo(null);
	mezu_ona_Frame.setVisible(true);
	
	mezu_ona_Button.addActionListener(new ActionListener() {
       	public void actionPerformed(ActionEvent e) {
       		mezu_ona_Frame.dispose();
        }
   });
	}
	
	public static void mezu_errorea(String a) {
	JFrame mezu_errorea_Frame = new JFrame("mezu_errorea_Frame");;
	JPanel mezu_errorea_Panel = new JPanel();
	JLabel mezu_errorea_Label = new JLabel(a);
	JButton mezu_errorea_Button = new JButton("Onartu");
	
	mezu_errorea_Panel.add(mezu_errorea_Label, BorderLayout.NORTH);
	mezu_errorea_Panel.add(mezu_errorea_Button, BorderLayout.NORTH);
	mezu_errorea_Frame.add(mezu_errorea_Panel);
	
	mezu_errorea_Frame.pack();
	mezu_errorea_Frame.setPreferredSize(new Dimension(500, 500));
	mezu_errorea_Frame.setLocationRelativeTo(null);
	mezu_errorea_Frame.setVisible(true);
	
	mezu_errorea_Button.addActionListener(new ActionListener() {
       	public void actionPerformed(ActionEvent e) {
       		mezu_errorea_Frame.dispose();
        }
   });
	}
}
